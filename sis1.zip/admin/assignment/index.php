<style>
    .img-thumb-path {
        width: 100px;
        height: 80px;
        object-fit: scale-down;
        object-position: center center;
    }
</style>

<div class="card card-outline card-primary rounded-0 shadow">
    <div class="card-header">
        <h3 class="card-title">List of Assignment</h3>
        <?php if ($_settings->userdata('type') == 1): ?>
        <!-- <div class="card-tools">
            <a href="javascript:void(0)" id="create_new" class="btn btn-flat btn-sm btn-primary"><span class="fas fa-plus"></span> Add New Teacher</a>
        </div> -->
        <?php endif; ?>
    </div>
    <div class="card-body">
        <div class="container-fluid">
            <table class="table table-bordered table-hover table-striped text-center">
                <colgroup>
                    <col width="10%">
                    <col width="90%">

                </colgroup>
                <thead>
                    <tr class="bg-gradient-dark text-light">
                        <th>#</th>

                        <th>Subject</th>
						<th>Topic</th>

                        <!-- <th>Action</th> -->
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $i = 1;
                    $qry = $conn->query("SELECT * FROM assigment ");
                    while ($row = $qry->fetch_assoc()):
                    ?>
                    <tr>
						
                        <td><?php echo $i++; ?></td>
                        <td><?php echo $row['subject'] ?></td>
                        <td><?php echo $row['topics'] ?></td>



                        <!-- <td align="center">
                            <button type="button" class="btn btn-flat btn-default btn-sm dropdown-toggle dropdown-icon" data-toggle="dropdown">
                                Action
                                <span class="sr-only">Toggle Dropdown</span>
                            </button>
                            <div class="dropdown-menu" role="menu">
                                <a class="dropdown-item view_data" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>"><span class="fa fa-eye text-dark"></span> View</a>
                                <?php if ($_settings->userdata('type') == 1): ?>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item edit_data" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>"><span class="fa fa-edit text-primary"></span> Edit</a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item delete_data" href="javascript:void(0)" data-id="<?php echo $row['id'] ?>"><span class="fa fa-trash text-danger"></span> Delete</a>
                                <?php endif; ?>
                            </div>
                        </td> -->
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
$(document).ready(function () {
    $('#create_new').click(function () {
        uni_modal("Add New Teacher", "teachers/manage_teacher.php")
    });
    $('.view_data').click(function () {
        uni_modal("Teacher Details", "teachers/view_teacher.php?id=" + $(this).attr('data-id'))
    });
    $('.edit_data').click(function () {
        uni_modal("Update Teacher Details", "teachers/manage_teacher.php?id=" + $(this).attr('data-id'))
    });
    $('.delete_data').click(function () {
        _conf("Are you sure to delete this teacher permanently?", "delete_teacher", [$(this).attr('data-id')])
    });
    $('.table td, .table th').addClass('py-1 px-2 align-middle');
    $('.table').dataTable({
        columnDefs: [
            { orderable: false, targets: 6 }
        ]
    });
});

function delete_teacher(id) {
    start_loader();
    $.ajax({
        url: _base_url_ + "classes/Master.php?f=delete_teacher",
        method: "POST",
        data: { id: id },
        dataType: "json",
        error: err => {
            console.log(err)
            alert_toast("An error occurred.", 'error');
            end_loader();
        },
        success: function (resp) {
            if (typeof resp === 'object' && resp.status == 'success') {
                location.reload();
            } else {
                alert_toast("An error occurred.", 'error');
                end_loader();
            }
        }
    });
}
</script>
